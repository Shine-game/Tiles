class_name TileGrowth
extends RefCounted

const SpriteTiming = preload("res://scripts/pattern/sprite_growth.gd")
const Connections = preload("res://scripts/pattern/connection_assembly.gd")
const Formations = preload("res://scripts/pattern/formation_assembly.gd")
const Timing = preload("res://scripts/pattern/growth_schedule.gd")
const Topology = preload("res://scripts/pattern/topology.gd")

# A deterministic event schedule in board coordinates. Rendering never changes it.
const STEP := 0.14
const CENTER_POP := 0.30
const LEAF_POP := 0.22
const GRID_FADE := 0.14
const FLOWER_POP := 0.36
const LINK_GROW := 0.18
const STAR_POP := 0.24
const RIPPLE := 0.18
const FLOWER_RADIUS := 1.0 / 3.0
const DIRECTIONS := [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]
var board: Array = []
var arrivals: Dictionary = {}
var edges: Array = []
var flowers: Dictionary = {}
var links: Array = []
var duration := 0.0
var sprite_growth_events: Dictionary = {}
var sprite_visual_duration := 0.0
var boundary_crossings: Dictionary = {}

static func value(grid: Array, cell: Vector2i) -> int:
	return Topology.value(grid, cell)

static func edge_key(a: Vector2i, b: Vector2i) -> Vector4i:
	return Topology.edge_key(a, b)

static func leaf_sprouts(edge: Dictionary) -> Array:
	var result: Array = []
	var directions: Array = [1, -1] if int(edge.flow) == 0 else [int(edge.flow)]
	for direction: int in directions:
		var fractions: Array = [0.12, 0.28, 0.43] if int(edge.flow) == 0 else [0.12, 0.34, 0.56, 0.78]
		for i in range(fractions.size()):
			var fraction: float = fractions[i]
			var start: float = -100 if edge.old else float(edge.start_a if direction == 1 else edge.start_b) + fraction * STEP
			for side: int in [-1, 1]:
				result.append({"fraction": fraction if direction == 1 else 1 - fraction, "direction": direction, "side": side, "start": start + (0.012 if side == 1 and not edge.old else 0)})
	return result

# Filled cells merge into a seamless terrace, even across pigment boundaries.
# This visual merge does not create a vine connection between different colors.
func grid_visibility(a: Vector2i, b: Vector2i, time: float) -> float:
	var key: Vector4i = edge_key(a, b)
	if not boundary_crossings.has(key):
		return 1.0
	var crossing: float = boundary_crossings[key]
	return 1.0 - smoothstep(crossing, crossing + GRID_FADE, time)

static func is_flower(grid: Array, corner: Vector2i, color: int) -> bool:
	# Compatibility adapter: legacy callers supply the shared inner corner.
	return Topology.is_formation(grid, corner - Vector2i.ONE, color)

func build(before: Array, after: Array) -> void:
	sprite_growth_events.clear()
	sprite_visual_duration = 0.0
	board = after.duplicate(true)
	arrivals.clear()
	edges.clear()
	flowers.clear()
	links.clear()
	boundary_crossings.clear()
	duration = 0
	var pending: Dictionary = {}
	for y in range(board.size()):
		for x in range(board.size()):
			var cell := Vector2i(x, y)
			var color: int = board[y][x]
			if color == 0:
				continue
			if value(before, cell) == color:
				arrivals[cell] = -100.0
			else:
				pending[cell] = true
	# Find each new same-color component. Existing neighbors are simultaneous
	# sources; an independent component awakens all of its centers at t=0.
	while not pending.is_empty():
		var first: Vector2i = pending.keys()[0]
		var component: Array = [first]
		pending.erase(first)
		var cursor := 0
		while cursor < component.size():
			var cell: Vector2i = component[cursor]
			cursor += 1
			for direction: Vector2i in DIRECTIONS:
				var neighbor := cell + direction
				if pending.has(neighbor) and value(board, neighbor) == value(board, cell):
					pending.erase(neighbor)
					component.append(neighbor)
		var wave: Array = []
		for cell: Vector2i in component:
			arrivals[cell] = INF
			for direction: Vector2i in DIRECTIONS:
				if value(before, cell + direction) == value(board, cell):
					arrivals[cell] = STEP
					wave.append(cell)
					break
		if wave.is_empty():
			for cell: Vector2i in component:
				arrivals[cell] = 0.0
		else:
			cursor = 0
			while cursor < wave.size():
				var cell: Vector2i = wave[cursor]
				cursor += 1
				for direction: Vector2i in DIRECTIONS:
					var neighbor := cell + direction
					if component.has(neighbor) and float(arrivals[neighbor]) > float(arrivals[cell]) + STEP:
						arrivals[neighbor] = float(arrivals[cell]) + STEP
						wave.append(neighbor)
		for cell: Vector2i in component:
			duration = maxf(duration, float(arrivals[cell]) + CENTER_POP)
	var lookup: Dictionary = {}
	for cell: Vector2i in arrivals:
		for direction: Vector2i in [Vector2i.RIGHT, Vector2i.DOWN]:
			var other := cell + direction
			if value(board, other) != value(board, cell):
				if value(board, other) != 0:
					var merge_time: float = -100.0 if value(before, cell) != 0 and value(before, other) != 0 else 0.0
					boundary_crossings[edge_key(cell, other)] = merge_time
					duration = maxf(duration, merge_time + GRID_FADE)
				continue
			var old: bool = value(before, cell) == value(board, cell) and value(before, other) == value(board, cell)
			var a: float = maxf(0, arrivals[cell])
			var b: float = maxf(0, arrivals[other])
			var finish: float = minf(a, b) + STEP if absf(a - b) >= STEP else (a + b + STEP) / 2.0
			var edge := {"a": cell, "b": other, "color": value(board, cell), "start_a": a, "start_b": b, "finish": 0.0 if old else finish, "old": old, "flow": 0 if is_equal_approx(a, b) else (1 if a < b else -1)}
			edges.append(edge)
			lookup[edge_key(cell, other)] = edge
			var crossing: float = -100 if old else minf(a, b) + STEP / 2
			boundary_crossings[edge_key(cell, other)] = crossing
			if not old:
				duration = maxf(duration, finish + maxf(maxf(RIPPLE, STAR_POP), LEAF_POP))
				duration = maxf(duration, crossing + GRID_FADE)
				for sprout: Dictionary in leaf_sprouts(edge):
					duration = maxf(duration, sprout.start + LEAF_POP)
	var formations := Formations.collect(before, board)
	for origin: Vector2i in formations:
		var corner := origin + Vector2i.ONE
		var color: int = formations[origin].color
		var old: bool = formations[origin].old
		var around := Formations.perimeter(formations[origin])
		var start := -100.0 if old else 0.0
		if not old:
			for i in range(4):
				start = maxf(start, lookup[edge_key(around[i], around[(i + 1) % 4])].finish)
			duration = maxf(duration, start + flower_seconds())
		flowers[corner] = {"color": color, "start": start, "old": old}
	for pair: Dictionary in Connections.pairs(flowers, Vector2i.ONE):
		var corner: Vector2i = pair.a
		var other: Vector2i = pair.b
		var old: bool = pair.old
		var start: float = Connections.start(pair, flowers, "start", flower_seconds() * flower_link_fraction())
		links.append({"a": corner, "b": other, "color": flowers[corner].color, "start": start, "old": old})
		if not old:
			duration = maxf(duration, start + LINK_GROW + STAR_POP)

func flower_seconds() -> float:
	return FLOWER_POP

func flower_link_fraction() -> float:
	return 0.45

func tier2_records() -> Dictionary:
	return Formations.bind_records(board, flowers, "", flower_seconds(), Vector2i.ONE)

# Add decorative lifetimes only after structural scheduling has completed.
# The shared component state extends its visual clock from these blocking events;
# tier 2/3 continue to read the original structural model duration/events.
func schedule_sprite_growth(plans: Dictionary, bindings: Dictionary, timeline: RefCounted, options: Dictionary = {}) -> Dictionary:
	if not timeline is SpriteTiming: return {"ok": false, "errors": ["Expected a PatternSpriteGrowth timeline"]}
	var timing := options.duplicate(true)
	timing.structural_duration = duration
	var result: Dictionary = timeline.reconcile(plans, bindings, timing)
	if result.ok:
		sprite_growth_events = result.events.duplicate(true)
		sprite_visual_duration = result.visual_duration
	return result
