extends Control

const Surface = preload("res://scripts/tile_surface.gd")
const Geometry = preload("res://scripts/piece_geometry.gd")
const Palette = preload("res://scripts/palette.gd")
var cells: Array = []
var origin := Vector2.ZERO
var pitch := 1.0
var color := 1
var valid := false
var face_lift := -1.0

func lift() -> float:
	return Surface.depth(pitch) if face_lift < 0 else face_lift

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	z_index = 30

func cell_at(point: Vector2) -> Vector2i:
	return Geometry.hit(cells,point,origin-Vector2(0,lift()),pitch)

func _draw() -> void:
	Surface.begin(self)
	# Placement validity controls the Place action; it must not hide the chosen color.
	var ink: Color = Palette.tile(color)
	Surface.draw_piece(self, cells, origin - Vector2(0, lift()), pitch, ink)
